'''
Contains our document collection
'''

class DocumentCollection:

    def __init__(self, documents):
        #TODO add source path and do the data loading and processing here
        self.documents = documents


    def getDocuments(self, documents):
        #TODO use self.documents path to load data
        #contains a list of (list of words/strings)
        self.documents = documents
        documentsProcessed = []
        for i in range(len(documents)):
            if documents[i] == '':
                continue
            documentsProcessed.append(documents[i].split())

        return documentsProcessed